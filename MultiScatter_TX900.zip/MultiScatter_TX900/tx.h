/*
 * tx.h
 *
 *  Created on: Nov 21, 2019
 *      Author: katanbaf
 */

#ifndef TX_H_
#define TX_H_

#include "rx.h"
#include <ti/drivers/SPI.h>

void init_tx();
void send_cw(RF_Handle* rfHandle, PIN_Handle* rfPinHandle, uint8_t power_cmd, uint16_t timeout);
void tx_waketag(RF_Handle* rfHandle, SPI_Handle* spi, uint8_t index, uint8_t tag_data, uint8_t wake_pow, uint8_t antenna);
void AS3933_data(uint8_t tag_id, uint8_t tag_data, uint8_t* data);
void AS3933_pattern(uint8_t* data, uint8_t* transmitBuffer, bool update_data);

#endif /* TX_H_ */
