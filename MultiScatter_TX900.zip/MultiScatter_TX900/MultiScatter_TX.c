/*
 * MultiScatter_TX.c
 *
 */

/***** Includes *****/
/* Standard C Libraries */
#include <stdlib.h>

/* TI Drivers */
#include <ti/drivers/rf/RF.h>
#include <ti/drivers/PIN.h>
#include <ti/drivers/UART.h>
#include <ti/drivers/SPI.h>
#include <ti/drivers/Watchdog.h>

/* Driverlib Header files */
#include DeviceFamily_constructPath(driverlib/rf_prop_mailbox.h)

/* Board Header files */
#include "ti_drivers_config.h"

/* Application Header files */
#include "RFQueue.h"
#include <ti_radio_config.h>
#include "rx.h"
#include "tx.h"
#include "board.h"

/***** Defines *****/
#define BOARD_ID (0x00)
#define SYNC_FREQ 915
#define TIMEOUT_MS      10000

/***** Prototypes *****/
static void init_uart();
static void init_spi();
static void init_leds();
static void init_watchdog();
void init_radio();
void set_freq(uint16_t freq, uint16_t fractFreq);
void watchdogCallback(uintptr_t watchdogHandle);

/***** Variable declarations *****/
static RF_Object rfObject;
static RF_Handle rfHandle;

/* Pin driver handle */
static PIN_Handle ledPinHandle;
static PIN_State ledPinState;
static PIN_Handle paPinHandle;
static PIN_State paPinState;
PIN_Handle paenPinHandle;
PIN_State paenPinState;

/* UART driver handle */
static UART_Handle uart;

/* SPI driver handle */
static SPI_Handle spi;
static SPI_Params spiParams;

/* Watchdog driver handle */
static Watchdog_Handle watchdogHandle;
static Watchdog_Params params;

/*
 * Application LED pin configuration table:
 *   - All LEDs board LEDs are off.
 */
PIN_Config ledPinTable[] =
{
    PIN_RLED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    PIN_GLED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
	PIN_TERMINATE
};

PIN_Config paPinTable[] =
{
    PIN_PA_VPC | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    PIN_PA_BYP | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    PIN_PA_TXRX | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    PIN_TERMINATE
};

PIN_Config paenPinTable[] =
{
    PIN_PA_EN | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    PIN_TERMINATE
};

/***** Function definitions *****/

void *mainThread(void *arg0)
{
    const char  start[] = "Start:\r\n";
    uint32_t reloadValue;


    RF_Params rfParams;
    RF_Params_init(&rfParams);

    init_leds();
    PIN_setOutputValue(ledPinHandle, PIN_RLED, 1);
    usleep(50000);
    init_uart();
    init_spi();
    UART_write(uart, start, sizeof(start));

    init_watchdog();
    reloadValue = Watchdog_convertMsToTicks(watchdogHandle, TIMEOUT_MS);
    if (reloadValue != 0)
    {
        Watchdog_setReload(watchdogHandle, reloadValue);
    }

    init_rxQueue();

    init_radio();
    init_rx();
    init_tx();

    /* Request access to the radio */
#if defined(DeviceFamily_CC26X0R2)
    rfHandle = RF_open(&rfObject, &RF_prop, (RF_RadioSetup*)&RF_cmdPropRadioSetup, &rfParams);
#else
    rfHandle = RF_open(&rfObject, &RF_prop, (RF_RadioSetup*)&RF_cmdPropRadioDivSetup, &rfParams);
#endif

    PIN_setOutputValue(ledPinHandle, PIN_RLED, 0);
    PIN_setOutputValue(ledPinHandle, PIN_GLED, 0);

    uint16_t sync_freq = SYNC_FREQ;
    uint16_t sync_fractFreq = 0x0000;

    uint16_t excite_freq = 904;
    uint16_t excite_fractFreq = 0x199a;

    sync_params sync_data;
    sync_data.power = 6;
    sync_data.timeout = 100;
    sync_data.helper_freq = 15;
    sync_data.helper_fractFreq = 0x00;


    while(1)
    {
        PIN_setOutputValue(ledPinHandle, PIN_GLED, !PIN_getOutputValue(PIN_GLED));
        Watchdog_clear(watchdogHandle);

        /*Get sync packet to helper*/
        PIN_setOutputValue(paPinHandle, PIN_PA_VPC, 1);
        PIN_setOutputValue(paPinHandle, PIN_PA_BYP, 1);
        PIN_setOutputValue(paPinHandle, PIN_PA_TXRX, 0);
        set_freq(sync_freq, sync_fractFreq);
        while(1)
        {
            sync_data.tx_id = 0xff;
            while(get_sync_pkt(&rfHandle, &uart, &sync_data, 500) == 0);
            if (sync_data.ver_seq == VER_SEQ && sync_data.tx_id == BOARD_ID)
                break;
        }

        if(sync_data.timeout > 5)
            sync_data.timeout -= 4;

        PIN_setOutputValue(paPinHandle, PIN_PA_VPC, 1);
        PIN_setOutputValue(paPinHandle, PIN_PA_BYP, 0);
        PIN_setOutputValue(paPinHandle, PIN_PA_TXRX, 1);

        excite_freq = 900 + sync_data.helper_freq;
        excite_fractFreq = sync_data.helper_fractFreq;

        //Wake tag
        spi = SPI_open(CONFIG_SPI_0, &spiParams);
        if (spi == NULL) {
            PIN_setOutputValue(ledPinHandle, PIN_RLED, 1);
            while (1);  // SPI_open() failed
        }
        set_freq(excite_freq, excite_fractFreq);
        tx_waketag(&rfHandle, &spi, sync_data.tag_id, sync_data.tag_cmd, 14, 0x00);
        SPI_close(spi);
//        usleep(100000);


        /*Transmit CW*/
        paenPinHandle = PIN_open(&paenPinState, paenPinTable);
        PIN_setOutputValue(paenPinHandle, PIN_PA_EN, 1);

        set_freq(excite_freq, excite_fractFreq);
        send_cw(&rfHandle, &paPinHandle, sync_data.power, (uint16_t)2*sync_data.timeout); //2ms resolution

        PIN_setOutputValue(paenPinHandle, PIN_PA_EN, 0);
        PIN_close(paenPinHandle);

//        if (sync_fractFreq == 0)
//        {
//            sync_fractFreq = 0x8000;
//        }
//        else
//        {
//            excite_freq += 1;
//            if (excite_freq > 928)
//                excite_freq = 902;
//        }
//
//        usleep(200000);

    }
}

void init_leds()
{
    /* Open LED pins */
    ledPinHandle = PIN_open(&ledPinState, ledPinTable);
    if (ledPinHandle == NULL)
    {
        PIN_setOutputValue(ledPinHandle, PIN_RLED, 1);
        while(1);
    }
}

void uart_writeCb (UART_Handle handle, void *buf, size_t count)
{

}

void init_uart()
{
    UART_Params uartParams;
    UART_Params_init(&uartParams);

    /* Open UART pins */
    UART_init();
    uartParams.readMode = UART_MODE_BLOCKING;
    uartParams.writeMode = UART_MODE_CALLBACK;
    uartParams.writeTimeout = UART_WAIT_FOREVER;
    uartParams.readTimeout = UART_WAIT_FOREVER;
    uartParams.readCallback = NULL;
    uartParams.writeCallback = uart_writeCb;
    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.readDataMode = UART_DATA_BINARY;
    uartParams.writeDataMode = UART_DATA_BINARY;
    uartParams.readEcho = UART_ECHO_OFF;
    uartParams.baudRate = 1000000;
    uartParams.dataLength = UART_LEN_8;
    uartParams.stopBits = UART_STOP_ONE;
    uartParams.parityType = UART_PAR_NONE;
    uart = UART_open(CONFIG_UART_0, &uartParams);

    if (uart == NULL) {
        /* UART_open() failed */
        PIN_setOutputValue(ledPinHandle, PIN_RLED, 1);
        while (1);
    }
}

void init_spi()
{
    SPI_init();  // Initialize the SPI driver
    SPI_Params_init(&spiParams);  // Initialize SPI parameters
    spiParams.dataSize = 8;       // 8-bit data size
    spiParams.bitRate = 250000;
    spiParams.frameFormat = SPI_POL0_PHA1;
}

void set_freq(uint16_t freq, uint16_t fractFreq)
{
    RF_cmdFs.frequency = freq;
    RF_cmdFs.fractFreq = fractFreq;
    RF_postCmd(rfHandle, (RF_Op*)&RF_cmdFs, RF_PriorityNormal, NULL, 0);
}

//Select one of the following options for the different data rates
/*31.25Kbps*/
//#define DEV         (100)
//#define RATEWORD    (0x5000)
//#define RXBW        (0x53)
/*62.5Kbps*/
//#define DEV         (100)
//#define RATEWORD    (0xa000)
//#define RXBW        (0x54)
/*125Kbps*/
#define DEV         (340)
#define RATEWORD    (0x14000)
#define RXBW        (0x58)
/*250Kbps*/
//#define DEV         (340)
//#define RATEWORD    (0x28000)
//#define RXBW        (0x5c)

void init_radio()
{
    /* Open RF pins */
    paPinHandle = PIN_open(&paPinState, paPinTable);
    if (paPinHandle == NULL)
    {
        PIN_setOutputValue(ledPinHandle, PIN_RLED, 1);
        while(1);
    }


    // Modulation & frequency Deviation
    RF_cmdPropRadioDivSetup.modulation.modType = 0;
    RF_cmdPropRadioDivSetup.modulation.deviation = DEV;
    RF_cmdPropRadioDivSetup.modulation.deviationStepSz = 0;
    RF_cmdPropRadioDivSetup.symbolRate.preScale = 0xF;
    RF_cmdPropRadioDivSetup.symbolRate.rateWord = RATEWORD;
    RF_cmdPropRadioDivSetup.rxBw = RXBW;
    RF_cmdPropRadioDivSetup.preamConf.nPreamBytes = 3;
    RF_cmdPropRadioDivSetup.preamConf.preamMode = 0;
    RF_cmdPropRadioDivSetup.formatConf.nSwBits = 24;
    RF_cmdPropRadioDivSetup.formatConf.bMsbFirst = 1;
    RF_cmdPropRadioDivSetup.formatConf.fecMode = 0;
    RF_cmdPropRadioDivSetup.formatConf.whitenMode = 6;
}

void rfDriverCallbackCustom(RF_Handle client, RF_GlobalEvent event, void* arg)
{

}

/*
 *  ======== watchdogCallback ========
 */
void watchdogCallback(uintptr_t watchdogHandle)
{
    /*
     * If the Watchdog Non-Maskable Interrupt (NMI) is called,
     * loop until the device resets. Some devices will invoke
     * this callback upon watchdog expiration while others will
     * reset. See the device specific watchdog driver documentation
     * for your device.
     */
    while (1)
    {
//        PIN_setOutputValue(ledPinHandle, PIN_GLED, !PIN_getOutputValue(PIN_GLED));
//        usleep(200000);
    }
}

void init_watchdog()
{
    Watchdog_init();
    /* Open a Watchdog driver instance */
    Watchdog_Params_init(&params);
    params.callbackFxn = (Watchdog_Callback) watchdogCallback;
    params.debugStallMode = Watchdog_DEBUG_STALL_ON;
    params.resetMode = Watchdog_RESET_ON;

    watchdogHandle = Watchdog_open(CONFIG_WATCHDOG_0, &params);
    if (watchdogHandle == NULL) {
        /* Error opening Watchdog */
        while (1) {}
    }
}
