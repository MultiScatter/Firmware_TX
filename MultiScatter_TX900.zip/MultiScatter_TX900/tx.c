/*
 * tx.c
 *
 *  Created on: Nov 21, 2019
 *      Author: katanbaf
 */




/* TI Drivers */
#include <ti/drivers/rf/RF.h>
#include <ti/drivers/PIN.h>
#include <ti/drivers/UART.h>

/* Board Header files */
#include "ti_drivers_config.h"

/* Application Header files */
#include "RFQueue.h"
#include <ti_radio_config.h>
#include "board.h"
#include "tx.h"

/***** Defines *****/
#define BIT_DURATION 15 // bit duration in subfrequency clk cycles,bit_rate = 125K/15 = 8.33Kbps
#define PREAMBLE_DURATION 125   // preamble duration in subfrequency clk cycles, equal to 125/125K = 1ms
#define DATA_LEN  (4+8+8)
#define MSGSIZE  ((PREAMBLE_DURATION * 2 + BIT_DURATION * 2 + BIT_DURATION * 4 * DATA_LEN) / 8 + 1)

/***** Prototypes *****/


/***** Variable declarations *****/
SPI_Transaction spiTransaction;
uint8_t         transmitBuffer[MSGSIZE];
uint8_t         receiveBuffer[MSGSIZE];
//static uint8_t tag_ids[16] = {0x0f, 0x1e, 0x2d, 0x3c, 0x4b, 0x5a, 0x69, 0x78, 0x87, 0x96, 0xa5, 0xb4, 0xc3, 0xd2, 0xe1, 0xf0};
static uint8_t tag_ids[16] = {0x00, 0x1e, 0x33, 0x2d, 0x66, 0x78, 0x55, 0x4b, 0xcc, 0xd2, 0xff, 0xe1, 0xaa, 0xb4, 0x99, 0x87};
uint8_t tag_data_buf[DATA_LEN];
extern PIN_Handle paenPinHandle;
extern PIN_State paenPinState;
extern PIN_Config paenPinTable[];

void init_tx()
{
    RF_cmdTxTest.config.bUseCw = 1;
    RF_cmdTxTest.config.bFsOff = 0;
    RF_cmdTxTest.endTrigger.triggerType = TRIG_REL_START;

    spiTransaction.count = MSGSIZE;
    spiTransaction.rxBuf = (void *)receiveBuffer;
    spiTransaction.txBuf = (void *)transmitBuffer;
}

void send_cw(RF_Handle* rfHandle, PIN_Handle* rfPinHandle, uint8_t power_cmd, uint16_t timeout)
{
    //(14->9.3),  (12->8.5), (10->6.7), (8->5.3), (7->4.2), (5->1.5), (4->0.9)
    //(2->-1.5), (1->-2.4), (0->-3.6), (-5->-10.5), (-10->-17), (-15->-22), (-20->-28)

    int8_t power = 0;
    if(power_cmd <= 4)
        power = (power_cmd * 5) - 20;
    else if(power_cmd < 19)
        power = (power_cmd - 4);
    else
        power = 0;
    RF_TxPowerTable_Value paVal = RF_TxPowerTable_findValue(txPowerTable, power);
    RF_setTxPower(*rfHandle, paVal);

    RF_cmdTxTest.config.bUseCw = 1;
    RF_cmdTxTest.config.bFsOff = 0;
    RF_cmdTxTest.endTrigger.triggerType = TRIG_REL_START;

    RF_cmdTxTest.endTime = RF_convertMsToRatTicks(timeout);
    RF_runCmd(*rfHandle, (RF_Op*)&RF_cmdTxTest, RF_PriorityNormal, NULL, 0);
}

void tx_waketag(RF_Handle* rfHandle, SPI_Handle* spi, uint8_t index, uint8_t tag_cmd, uint8_t wake_pow, uint8_t antenna)
{
    RF_CmdHandle TX;

    AS3933_data(tag_ids[index], tag_cmd, tag_data_buf);
    AS3933_pattern(tag_data_buf, transmitBuffer, 0);

    RF_cmdTxTest.endTrigger.triggerType = TRIG_NEVER;
    RF_cmdTxTest.config.bUseCw = 0x1;
    RF_cmdTxTest.config.whitenMode = 0x0;

    /* Send CMD_TX_TEST which sends forever */
    RF_TxPowerTable_Value paVal = RF_TxPowerTable_findValue(txPowerTable, wake_pow);
    RF_setTxPower(*rfHandle, paVal);
    TX = RF_postCmd(*rfHandle, (RF_Op*)&RF_cmdTxTest, RF_PriorityNormal, NULL, 0);

    SPI_transfer(*spi, &spiTransaction);

//    paenPinHandle = PIN_open(&paenPinState, paenPinTable);
//    PIN_setOutputValue(paenPinHandle, PIN_PA_EN, 1);
//    usleep(100000);
//    PIN_close(paenPinHandle);

    RF_cancelCmd(*rfHandle, TX, 0);
}


void AS3933_data(uint8_t tag_id, uint8_t tag_data, uint8_t* data)
{
    uint8_t i;
    data[0] = 1;
    data[1] = 1;
    data[2] = 1;
    for (i=0; i<8; ++i)
        data[3+i] = (tag_id & (0x80 >> i)) != 0;
    for (i=0; i<8; ++i)
        data[11+i] = (tag_data & (0x80 >> i)) != 0;
}

void AS3933_pattern(uint8_t* data, uint8_t* transmitBuffer, bool update_data)
{
    uint8_t i;
    uint8_t j;
    uint8_t first_value;
    uint8_t second_value;
    uint8_t start_index;
    uint16_t start_byte_index;
    uint16_t start_byte_position;
    uint16_t mid_byte_index;
    uint16_t mid_byte_position;
    uint16_t end_byte_index;
    uint16_t end_byte_position;
    uint16_t bit_index;

    if (update_data == 0){
        for(i=0; i < MSGSIZE; ++i)
            transmitBuffer[i] = 0;
        for(i=0; i < (PREAMBLE_DURATION * 2)/8; ++i)
            transmitBuffer[i] = 0xaa;

        transmitBuffer[(PREAMBLE_DURATION * 2)/8] = 0x80;
        transmitBuffer[(PREAMBLE_DURATION * 2)/8+1] = 0;
        transmitBuffer[(PREAMBLE_DURATION * 2)/8+2] = 0;
        transmitBuffer[(PREAMBLE_DURATION * 2)/8+3] = 0;
        start_index = 0;
        bit_index = (PREAMBLE_DURATION * 2 + BIT_DURATION * 2 );
    }
    else{
        start_index = 11;
        bit_index = (PREAMBLE_DURATION * 2 + BIT_DURATION * 2 + (11)*BIT_DURATION * 4);
        for(i=bit_index/8; i < MSGSIZE; ++i)
            transmitBuffer[i] = 0;
    }


    for(i=start_index; i < DATA_LEN; ++i){
        //Manchester coding
        if (data[i] == 1){
            first_value = 0xaa;
            second_value = 0x00;
        }
        else{
            first_value = 0x00;
            second_value = 0xaa;
        }
        //find the transition indexes
        start_byte_index = bit_index / 8;
        start_byte_position = bit_index % 8;
        mid_byte_index = (bit_index + BIT_DURATION * 2) / 8;
        mid_byte_position = (bit_index + BIT_DURATION * 2) % 8;
        end_byte_index = (bit_index + BIT_DURATION * 4) / 8;
        end_byte_position = (bit_index + BIT_DURATION * 4) % 8;

        //fill the bytes
        transmitBuffer[start_byte_index] |= first_value >> start_byte_position;
        for (j=start_byte_index+1; j<mid_byte_index; j++)
        {
            transmitBuffer[j] |= first_value;
        }
        if (mid_byte_position != 0)
            transmitBuffer[mid_byte_index] |= first_value << (8 - mid_byte_position);

        transmitBuffer[mid_byte_index] |= second_value >> mid_byte_position;
        for (j=mid_byte_index+1; j<end_byte_index; j++)
        {
            transmitBuffer[j] |= second_value;
        }
        if (end_byte_position != 0)
            transmitBuffer[end_byte_index] |= second_value << ( 8 - end_byte_position);
        bit_index += BIT_DURATION * 4;
    }
}
