/*
 * rx.c
 *
 *  Created on: Nov 19, 2019
 *      Author: katanbaf
 */

/* TI Drivers */
#include <ti/drivers/rf/RF.h>
#include <ti/drivers/PIN.h>
#include <ti/drivers/UART.h>

/* Board Header files */
#include "ti_drivers_config.h"

/* Application Header files */
#include "RFQueue.h"
#include <ti_radio_config.h>
#include "rx.h"

/***** Defines *****/
/* Packet RX Configuration */
#define DATA_ENTRY_HEADER_SIZE 8  /* Constant header size of a Generic Data Entry */
#define MAX_LENGTH             30 /* Max length byte the radio will accept */
#define NUM_DATA_ENTRIES       2  /* NOTE: Only two data entries supported at the moment */
#define NUM_APPENDED_BYTES     5  /* The Data Entries data field will contain:
                                   * 1 Header byte (RF_cmdPropRx.rxConf.bIncludeHdr = 0x1)
                                   * Max 30 payload bytes
                                   * 1 status byte (RF_cmdPropRx.rxConf.bAppendStatus = 0x1) */

//// Convert microseconds into RAT ticks.
//#define RF_convertUsToRatTicks(microseconds)  ((uint32_t)(microseconds) * RF_RAT_TICKS_PER_US)
//
//// Convert milliseconds into RAT ticks.
//#define RF_convertMsToRatTicks(milliseconds)  RF_convertUsToRatTicks((milliseconds) * 1000)


/***** Prototypes *****/
static void rx_callback(RF_Handle h, RF_CmdHandle ch, RF_EventMask e);
static void rx_timeoutCb(RF_Handle h, RF_RatHandle rh, RF_EventMask e, uint32_t compareCaptureTime);

/* Buffer which contains all Data Entries for receiving data.
 * Pragmas are needed to make sure this buffer is 4 byte aligned (requirement from the RF Core) */
#if defined(__TI_COMPILER_VERSION__)
#pragma DATA_ALIGN (rxDataEntryBuffer, 4);
static uint8_t
rxDataEntryBuffer[RF_QUEUE_DATA_ENTRY_BUFFER_SIZE(NUM_DATA_ENTRIES,
                                                  MAX_LENGTH,
                                                  NUM_APPENDED_BYTES)];
#elif defined(__IAR_SYSTEMS_ICC__)
#pragma data_alignment = 4
static uint8_t
rxDataEntryBuffer[RF_QUEUE_DATA_ENTRY_BUFFER_SIZE(NUM_DATA_ENTRIES,
                                                  MAX_LENGTH,
                                                  NUM_APPENDED_BYTES)];
#elif defined(__GNUC__)
static uint8_t
rxDataEntryBuffer[RF_QUEUE_DATA_ENTRY_BUFFER_SIZE(NUM_DATA_ENTRIES,
                                                  MAX_LENGTH,
                                                  NUM_APPENDED_BYTES)]
                                                  __attribute__((aligned(4)));
#else
#error This compiler is not supported.
#endif


//extern RF_Handle rfHandle;
//extern PIN_Handle ledPinHandle;
//extern UART_Handle uart;


/* Receive dataQueue for RF Core to fill in data */
static dataQueue_t dataQueue;
static rfc_dataEntryGeneral_t* currentDataEntry;
static uint8_t packetLength;
static uint8_t* packetDataPointer;
static uint8_t packet[MAX_LENGTH + NUM_APPENDED_BYTES - 1]; /* The length byte is stored in a separate variable */

/***** Variable declarations *****/
static volatile bool bpacketReceived = false;
static volatile bool bPacketsLost = false;
static RF_CmdHandle rxCmdHndl = 0; // Handle needed to abort the RX command
static volatile RF_RatConfigCompare ratCompareConfig;
static volatile RF_RatHandle ratHandle = RF_ALLOC_ERROR;
static ratmr_t  currTimerVal = 0, rxTimeoutVal = 0;
static rfc_propRxOutput_t rxStat;

void init_rxQueue()
{
    if( RFQueue_defineQueue(&dataQueue,
                                rxDataEntryBuffer,
                                sizeof(rxDataEntryBuffer),
                                NUM_DATA_ENTRIES,
                                MAX_LENGTH + NUM_APPENDED_BYTES))
    {
        /* Failed to allocate space for all data entries */
        while(1);
    }
}

void init_rx()
{
    /* Modify CMD_PROP_RX command for application needs */
    RF_cmdPropRx.pQueue = &dataQueue;
    RF_cmdPropRx.rxConf.bAutoFlushIgnored = 1;
    RF_cmdPropRx.rxConf.bAutoFlushCrcErr = 1;
    RF_cmdPropRx.maxPktLen = MAX_LENGTH;
    RF_cmdPropRx.pktConf.bRepeatOk = 1;
    RF_cmdPropRx.pktConf.bRepeatNok = 1;
    RF_cmdPropRx.pktConf.bFsOff = 0;
    RF_cmdPropRx.pOutput = (uint8_t*)&rxStat;
    RF_cmdPropRx.endTrigger.triggerType = TRIG_NEVER;
    RF_cmdPropRx.syncWord = 0x0055904E;

    /* Init RF_Rat */
    RF_RatConfigCompare_init((RF_RatConfigCompare *)&ratCompareConfig);
    ratCompareConfig.callback = (RF_RatCallback)&rx_timeoutCb;
    ratCompareConfig.channel  = RF_RatChannelAny;
}

uint8_t get_sync_pkt(RF_Handle* rfHandle, UART_Handle* uart, sync_params* data, uint16_t rx_timeout)
{
    uint8_t i;
    uint8_t packetReceived = 0;
    bpacketReceived = false;
    bPacketsLost = false;

    rxCmdHndl = RF_postCmd(*rfHandle, (RF_Op*)&RF_cmdPropRx, RF_PriorityNormal, &rx_callback, RF_EventRxEntryDone);

    rxTimeoutVal = RF_convertMsToRatTicks(rx_timeout);
    currTimerVal = RF_getCurrentTime();
    ratCompareConfig.timeout = currTimerVal + rxTimeoutVal;
    ratHandle = RF_ratCompare(*rfHandle, (RF_RatConfigCompare *)&ratCompareConfig, NULL);

    while(1)
    {
        if(bpacketReceived)
        {
            if(packetLength > MAX_LENGTH + NUM_APPENDED_BYTES - 1)
                packetLength = MAX_LENGTH + NUM_APPENDED_BYTES - 1;
            for (i=0; i<packetLength; ++i)
                packet[i] = packetDataPointer[i];
            packet[i++] = rxStat.lastRssi;
            packet[i++] = 0x55;
            packet[i++] = 0xaa;
            UART_write(*uart, packet, packetLength+3);

            data->tx_id = packet[0];
            data->tag_id = packet[1];
            data->helper_freq = packet[2];
            data->helper_fractFreq = packet[3] << 8 | packet[4];
            data->tag_cmd = packet[5];
            data->timeout = packet[6];
            data->power = (packet[7] >> 2) & 0x3f;
            data->wake_up = (packet[7] >> 1) & 0x01;
            data->tx_ant = packet[7] & 0x01;
            data->ver_seq = packet[8] << 8 | packet[9];
            bpacketReceived = false;
            packetReceived = 1;
            break;
        }
        else if(bPacketsLost)
        {
            break;
        }
    }
    RF_ratDisableChannel(*rfHandle, ratHandle);
    RF_cancelCmd(*rfHandle, rxCmdHndl, 0);

    return packetReceived;
}

void rx_callback(RF_Handle h, RF_CmdHandle ch, RF_EventMask e)
{
    if (e & RF_EventRxEntryDone)
    {
        /* Get current unhandled data entry */
        currentDataEntry = RFQueue_getDataEntry();

        RFQueue_nextEntry();

        /* Handle the packet data, located at &currentDataEntry->data:
         * - Length is the first byte with the current configuration
         * - Data starts from the second byte */
        packetLength      = *(uint8_t*)(&currentDataEntry->data);
        packetDataPointer = (uint8_t*)(&currentDataEntry->data + 1);

        /* Copy the payload + the status byte to the packet variable */  // Cause the CPU to Crash!!
//        memcpy(packet, packetDataPointer, (packetLength + 1));

        bpacketReceived = true;
    }
}

void rx_timeoutCb(RF_Handle h, RF_RatHandle rh, RF_EventMask e, uint32_t compareCaptureTime)
{
    bPacketsLost = true;
}
